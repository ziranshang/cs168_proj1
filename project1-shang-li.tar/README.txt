CS 168 Project 1

1. Ziran Shang, cs168-mg. Yeung John Li, cs168-hw

2. We ran into several bugs that took us a long time to debug.

3. A feature would be to add a hold time for routers to avoid loop formation in virtually all cases. This works as the router will refuse route updates for some time after refraction. However, this would cause a significant increase in convergence times.

4. Our code doesn't handle link weights or do incremental updates.
